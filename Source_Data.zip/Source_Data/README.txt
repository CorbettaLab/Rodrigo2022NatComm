#################### README ######################

Set of data to replicate the analysis and the models of the paper titled "Recovery of neural dynamics criticality in personalized whole brain models of stroke". 


    Legend
    
    A             activity
    SDA           standard deviation of A
    H             FC entropy
    H_SC          SC entropy
    K             av. degree
    Q             modularity
    E             efficiency
    S1            first cluster size
    I1            integral of S1
    S2            second cluster size
    I2            integral of S2
    B             av. behaviour
    label         controls / patients ID
    RSN           resting state networks
    pat1          1 year patient 
    pat3          3 months patient


